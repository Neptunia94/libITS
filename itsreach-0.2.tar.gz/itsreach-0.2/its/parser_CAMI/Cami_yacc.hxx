/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     IDENT = 258,
     DENT = 259,
     ENTIER = 260,
     ESPACE = 261,
     DB = 262,
     FB = 263,
     CA = 264,
     CT = 265,
     CN = 266,
     CM = 267,
     CP = 268,
     LOSS = 269,
     COMMENTAIRE = 270,
     PO = 271,
     PT = 272,
     PI = 273,
     NET = 274,
     PLACE = 275,
     QUEUE = 276,
     TRANSITION = 277,
     IMMEDIATE = 278,
     NAME = 279,
     DECLARATION = 280,
     AUTHORS = 281,
     CAMIVERSION = 282,
     TITLE = 283,
     PROJECT = 284,
     DATE = 285,
     CODE = 286,
     DOMAINE = 287,
     COMPONENT = 288,
     GUARD = 289,
     PRIORITY = 290,
     DELAY = 291,
     ACTION = 292,
     WEIGHT = 293,
     CAPACITY = 294,
     VALUATION = 295,
     MARKING = 296,
     ARC = 297,
     INHIBITOR = 298
   };
#endif
/* Tokens.  */
#define IDENT 258
#define DENT 259
#define ENTIER 260
#define ESPACE 261
#define DB 262
#define FB 263
#define CA 264
#define CT 265
#define CN 266
#define CM 267
#define CP 268
#define LOSS 269
#define COMMENTAIRE 270
#define PO 271
#define PT 272
#define PI 273
#define NET 274
#define PLACE 275
#define QUEUE 276
#define TRANSITION 277
#define IMMEDIATE 278
#define NAME 279
#define DECLARATION 280
#define AUTHORS 281
#define CAMIVERSION 282
#define TITLE 283
#define PROJECT 284
#define DATE 285
#define CODE 286
#define DOMAINE 287
#define COMPONENT 288
#define GUARD 289
#define PRIORITY 290
#define DELAY 291
#define ACTION 292
#define WEIGHT 293
#define CAPACITY 294
#define VALUATION 295
#define MARKING 296
#define ARC 297
#define INHIBITOR 298




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 73 "Cami_yacc.yxx"
{
   int  j;
  char *s;
  struct cami::LossCty LC;  //pour les attributs Loss et capacity
}
/* Line 1529 of yacc.c.  */
#line 141 "Cami_yacc.hxx"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE Camilval;

